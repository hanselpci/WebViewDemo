var searchData=
[
  ['version_0',['version',['../structwebview__version__info__t.html#a92df7155bc334cdd93285b82d7aabee7',1,'webview_version_info_t']]],
  ['version_5fnumber_1',['version_number',['../structwebview__version__info__t.html#a9c017fdf1014e7386ca8f85423c428bc',1,'webview_version_info_t']]]
];
