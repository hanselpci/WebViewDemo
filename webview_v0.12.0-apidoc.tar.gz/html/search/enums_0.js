var searchData=
[
  ['webview_5ferror_5ft_0',['webview_error_t',['../webview_2webview_8h.html#ac7542b2f1b310d178ee395bbc97e3716',1,'webview.h']]],
  ['webview_5fhint_5ft_1',['webview_hint_t',['../webview_2webview_8h.html#aaf5b04451f1c4f168d1ee8f6188b2282',1,'webview.h']]],
  ['webview_5fnative_5fhandle_5fkind_5ft_2',['webview_native_handle_kind_t',['../webview_2webview_8h.html#a5a0f06a996e8379a048e7eb17b38beda',1,'webview.h']]]
];
