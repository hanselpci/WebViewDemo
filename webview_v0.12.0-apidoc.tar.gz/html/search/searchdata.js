var indexSectionsWithContent =
{
  0: "bdlmpvw",
  1: "w",
  2: "w",
  3: "w",
  4: "bmpv",
  5: "w",
  6: "w",
  7: "w",
  8: "w",
  9: "dl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

