var searchData=
[
  ['build_5fmetadata_0',['build_metadata',['../structwebview__version__info__t.html#a0b62dc9932673f0ac9ec59edec21566b',1,'webview_version_info_t']]]
];
