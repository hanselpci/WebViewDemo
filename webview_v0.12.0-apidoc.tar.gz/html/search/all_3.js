var searchData=
[
  ['major_0',['major',['../structwebview__version__t.html#a3b45ce73be0a10684e2b388ca73864c3',1,'webview_version_t']]],
  ['minor_1',['minor',['../structwebview__version__t.html#a98736e1accfc37f6086b44355f4b0e9a',1,'webview_version_t']]]
];
