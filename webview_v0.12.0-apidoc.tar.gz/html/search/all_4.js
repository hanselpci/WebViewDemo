var searchData=
[
  ['patch_0',['patch',['../structwebview__version__t.html#adcb78ad2fa1710ee2ea5b6707fbd2231',1,'webview_version_t']]],
  ['pre_5frelease_1',['pre_release',['../structwebview__version__info__t.html#aefc8459bdb1f9b3d36bc42c7a9609063',1,'webview_version_info_t']]]
];
